document.addEventListener("click", function(e){
    if(e.target.classList.contains("edit-me")){
        let ans = prompt("Enter your desired new text",e.target.parentElement.parentElement.querySelector(".item-text").innerHTML)
        if(ans){
            axios.post('/update-item', {text: ans, id: e.target.getAttribute("data-id")}).then(function(){
                e.target.parentElement.parentElement.querySelector(".item-text").innerHTML = ans
            }).catch(function(){
                //pre-populate prompt box
            })
        }
    }
})

